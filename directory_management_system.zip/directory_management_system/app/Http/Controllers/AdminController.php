<?php

namespace App\Http\Controllers;

use App\Models\Directory;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('admin_login');
    }
    public function dashboard()
    {
        $total_directory=Directory::count();
        $private_directory=Directory::where('status','private')->count();
        $public_directory=Directory::where('status','public')->count();
        return view('admin.dashboard',compact('total_directory','private_directory','public_directory'));
    }
    public function add_directory()
    {
        return view('admin.add_directory');
    }
    public function manage_directory()
    {
        $directories=Directory::orderBy('id','desc')->get();
        return view('admin.manage_directory',compact('directories'));
    }
    public function public_directory()
    {
        $directories=Directory::orderBy('id','desc')->where('status','public')->get();
        return view('admin.public_directory',compact('directories'));
    }
    public function private_directory()
    {
        $directories=Directory::orderBy('id','desc')->where('status','private')->get();
        return view('admin.private_directory',compact('directories'));
    }
    public function search_directory(Request $request)
    {

        $val="";
        if($request->has('search'))
        {
            // $request->validate([
            //     'search'=>'required'
            // ]);

            $searchTerm=$request->input('search');
            $val=$searchTerm;
            // $data = Directory::where('status', 'public')->where(function ($query) use ($searchTerm) {
            //  $query->where('full_name', 'like', '%' . $searchTerm . '%')
            // ->orWhere('profession', 'like', '%' . $searchTerm . '%')
            // ->orWhere('email', 'like', '%' . $searchTerm . '%')
            // ->orWhere('mobile', 'like', '%' . $searchTerm . '%')
            // ->orWhere('city', 'like', '%' . $searchTerm . '%')
            // ->orWhere('address', 'like', '%' . $searchTerm . '%');
            //  })->get();

            $data = Directory::where(function ($query) use ($searchTerm) {
             $query->where('full_name', 'like', '%' . $searchTerm . '%')
            ->orWhere('profession', 'like', '%' . $searchTerm . '%')
            ->orWhere('email', 'like', '%' . $searchTerm . '%')
            ->orWhere('mobile', 'like', '%' . $searchTerm . '%')
            ->orWhere('city', 'like', '%' . $searchTerm . '%')
            ->orWhere('address', 'like', '%' . $searchTerm . '%');
             })->get();
        }
        return view('admin.search_directory',['data'=>$data,'val'=>$val]);
    }
    public function edit_directory($id)
    {
        $directory=Directory::find($id);
        return view('admin.edit_directory')->with('directory',$directory);
    }
    public function update_directory(Request $request,$id)
    {
        $request->validate([
            'full_name'=>'required|regex:/^[a-zA-Z ]+$/',
            'profession'=>'required|regex:/^[a-zA-Z ]+$/',
            'email'=>'required|email|unique:directories,email,'.$id,
            'mobile'=>'required|regex:/^\d{10}$/|unique:directories,mobile,'.$id,
            'city'=>'required|regex:/^[a-zA-Z ]+$/',
            'address'=>'required|regex:/^[a-zA-Z0-9\s.,#-]+$/',
            'status'=>'required|in:public,private'
        ],[
            'email.email'=>'email not valid',
            'mobile.regex'=>'mobile no not valid'
        ]);

        $directory=Directory::find($id);
        $directory->full_name=$request->input('full_name');
        $directory->profession=$request->input('profession');
        $directory->email=$request->input('email');
        $directory->mobile=$request->input('mobile');
        $directory->city=$request->input('city');
        $directory->address=$request->input('address');
        $directory->status=$request->input('status');

        try
        {
            $directory->save();
            $message="Directory updated successfully";
            return redirect()->route('admin.manage_directory')->with('message',$message);
        }
        catch(Exception $e)
        {
            $message="Error to update Directory";
            return redirect()->route('admin.manage_directory')->with('message',$message);
        }
    }
    public function store_add_directory(Request $request)
    {
        $request->validate([
            'full_name'=>'required|regex:/^[a-zA-Z ]+$/',
            'profession'=>'required|regex:/^[a-zA-Z ]+$/',
            'email'=>'required|email|unique:directories,email',
            'mobile'=>'required|regex:/^\d{10}$/|unique:directories,mobile',
            'city'=>'required|regex:/^[a-zA-Z ]+$/',
            'address'=>'required|regex:/^[a-zA-Z0-9\s.,#-]+$/'
        ],[
            'email.email'=>'email not valid',
            'mobile.regex'=>'mobile no not valid'
        ]);

        $directory=new Directory();
        $directory->full_name=$request->input('full_name');
        $directory->profession=$request->input('profession');
        $directory->email=$request->input('email');
        $directory->mobile=$request->input('mobile');
        $directory->city=$request->input('city');
        $directory->address=$request->input('address');

        try
        {
            $directory->save();
            $message="Directory added successfully";
            return redirect()->back()->with('message',$message);
        }
        catch(Exception $e)
        {
            $message="Error to add Directory";
            return redirect()->back()->with('message',$message);
        }
    }

    public function delete_directory($id)
    {

        $directory=Directory::find($id);
        try
        {
            $directory->delete();
            $message="Directory deleted successfully";
            return $message;
        }
        catch(Exception $e)
        {
            $message="Error to delete Directory";
            return $message;
        }
    }

    public function logout()
    {
        Session::forget('aid');
        return redirect('/');
    }
}
