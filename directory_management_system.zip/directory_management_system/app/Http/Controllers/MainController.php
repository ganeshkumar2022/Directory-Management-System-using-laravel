<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Directory;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function index(Request $request)
    {
         $data=Directory::where('status','public')->get();
        $val="";
        if($request->has('search'))
        {
            $searchTerm=$request->input('search');
            $val=$searchTerm;
            $data = Directory::where('status', 'public')->where(function ($query) use ($searchTerm) {
             $query->where('full_name', 'like', '%' . $searchTerm . '%')
            ->orWhere('profession', 'like', '%' . $searchTerm . '%')
            ->orWhere('email', 'like', '%' . $searchTerm . '%')
            ->orWhere('mobile', 'like', '%' . $searchTerm . '%')
            ->orWhere('city', 'like', '%' . $searchTerm . '%')
            ->orWhere('address', 'like', '%' . $searchTerm . '%');
             })->get();

        }
        return view('home',['data'=>$data,'val'=>$val]);
    }
    public function admin_login()
    {
        return view('login');
    }
    public function verify_login(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required|string'
        ],[
            'email.email'=>'Email address not valid'
        ]);

        $email=$request->input('email');
        $password=$request->input('password');


        if($user=Admin::where('email',$email)->first())
        {
            if(password_verify($password,$user->password))
            {
                $message="Login successfully";
                session(['aid'=>$user->id]);
                return redirect()->route('admin.dashboard');

            }
            else
            {
                $message="Email or password incorrect";
                return redirect()->route('main.admin_login')->with('message',$message);
            }
        }
        else
        {
            $message="Email or password incorrect";
            return redirect()->route('main.admin_login')->with('message',$message);
        }
    }
}
