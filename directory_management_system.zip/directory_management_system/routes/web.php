<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\MainController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::group(['as'=>'main.'],function(){
    Route::get("/",[MainController::class,"index"])->name('home');
    Route::get("/admin_login",[MainController::class,"admin_login"])->name('admin_login');
    Route::post("/verify_login",[MainController::class,"verify_login"])->name('verify_login');
});

Route::group(['prefix'=>'admin','as'=>'admin.'],function(){
    Route::get("/dashboard",[AdminController::class,"dashboard"])->name('dashboard');
    Route::get("/directory/add",[AdminController::class,"add_directory"])->name('add_directory');
    Route::get("/directory/manage",[AdminController::class,"manage_directory"])->name('manage_directory');
    Route::get("directory/edit/{id}",[AdminController::class,"edit_directory"])->name('edit_directory');
    Route::put("/directory/update/{id}",[AdminController::class,"update_directory"])->name('update_directory');
    Route::delete("/directory/delete/{id}",[AdminController::class,"delete_directory"])->name('delete_directory');
    Route::post("/verify_add_directory",[AdminController::class,"store_add_directory"])->name('store_add_directory');
    Route::get("/directory/public",[AdminController::class,"public_directory"])->name('public.directory');
    Route::get("/directory/private",[AdminController::class,"private_directory"])->name('private.directory');
    Route::get("/directory/search",[AdminController::class,"search_directory"])->name('directory.search');
    Route::get("/logout",[AdminController::class,"logout"])->name('logout');
});
