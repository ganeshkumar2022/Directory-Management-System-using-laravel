<?php $__env->startSection('title','Directory Management System | Home page'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.main_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Home / Search Directory</h5></div>
       <div class="card-body">
        <form method="get" action="<?php echo e(route('main.home')); ?>" autocomplete="off">
            <div class="input-group">
              <input type="text" class="form-control" name="search" value="<?php echo e($val); ?>" placeholder="Enter Full name / Profession / Email / Mobile / City / Address">
              <button class="btn btn-success" type="submit">Go</button>
            </div>
            <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-danger"><?php echo e($errors->first('search')); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>

        <div class="my-2">
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card my-1">
                        <div class="card-body">
                            Full Name : <?php echo e($row->full_name); ?> <br>
                            Profession : <?php echo e($row->profession); ?> <br>
                            Email : <?php echo e($row->email); ?> <br>
                            Mobile : <?php echo e($row->mobile); ?> <br>
                            City : <?php echo e($row->city); ?> <br>
                            Address : <?php echo e($row->address); ?> <br>

                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($data)==0 && @$_REQUEST['search']!=""): ?>
                  <center>No Directories found</center>
                <?php endif; ?>
            </div>
        </div>
       </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("body").css({"background-image":"url('assets/images/bg.jpg')","background-repeat":"no-repeat","background-size":"100% 100%","background-attachment":"fixed"});
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/home.blade.php ENDPATH**/ ?>