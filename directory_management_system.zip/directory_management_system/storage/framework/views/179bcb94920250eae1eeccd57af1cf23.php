<?php $__env->startSection('title','Admin panel | Manage Directory'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory / Manage</h5></div>
       <div class="card-body">
        <table class="table table-bordered">
            <thead class="table-primary">
            <tr>
                <th>S.No</th>
                <th>Full name</th>
                <th>profession</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Address</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Manage</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $directories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$directory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+=1); ?></td>
                <td><?php echo e($directory->full_name); ?></td>
                <td><?php echo e($directory->profession); ?></td>
                <td><?php echo e($directory->email); ?></td>
                <td><?php echo e($directory->mobile); ?></td>
                <td><?php echo e($directory->city); ?></td>
                <td><?php echo e($directory->address); ?></td>
                <td>
                    <span class="badge <?php echo e($directory->status=='public' ? 'bg-success' : 'bg-danger'); ?> rounded-pill">
                    <?php echo e($directory->status); ?>

                    </span>
                </td>
                <td><?php echo e($directory->created_at); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.edit_directory',$directory->id)); ?>" class="btn btn-success">Edit</a>
                    <button onclick="delete_record(<?php echo e($directory->id); ?>)" type="button" class="btn btn-danger">Delete</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($directories)==0): ?>
            <tr>
                <td colspan="10">No records found</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
       </div>
    </div>
</div>

<script>
    function delete_record(id)
    {
        var r=confirm("Are you sure you want to Delete");
        if(r)
        {
            var xhttp=new XMLHttpRequest();
            xhttp.onload=function(){
                alert(this.responseText);
                console.log(this.responseText);
                window.location.replace(window.location.href);
            }
            var text="<?php echo e(route('admin.delete_directory',':id')); ?>";
            txt=text.replace(':id',id);
            xhttp.open("DELETE",txt,true);
            xhttp.setRequestHeader("X-CSRF-TOKEN","<?php echo e(csrf_token()); ?>");
            xhttp.send();

        }
        else
        {
            alert('cancelled successfully');
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/admin/manage_directory.blade.php ENDPATH**/ ?>