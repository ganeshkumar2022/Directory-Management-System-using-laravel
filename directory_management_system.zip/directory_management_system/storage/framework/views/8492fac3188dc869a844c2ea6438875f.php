<?php $__env->startSection('title','Admin panel | Add Directory'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory / Add</h5></div>
       <div class="card-body">

            <form action="<?php echo e(route('admin.store_add_directory')); ?>" method="post" autocomplete="off">
            <?php echo csrf_field(); ?>
            <div class="mb-3 mt-3">
                <label for="full_name" class="form-label">Full name:</label>
                <input type="text" class="form-control" id="full_name" value="<?php echo e(old('full_name')); ?>" placeholder="Enter full name" name="full_name">
                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('full_name')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="profession" class="form-label">Profession:</label>
                <input type="text" class="form-control" id="profession" value="<?php echo e(old('profession')); ?>" placeholder="Enter profession" name="profession">
                <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('profession')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 mt-3">
                <label for="email" class="form-label">Email address:</label>
                <input type="text" class="form-control" id="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" name="email">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="mobile" class="form-label">Mobile no:</label>
                <input type="text" class="form-control" id="mobile" onkeypress="return check_number(event)" maxlength="10" value="<?php echo e(old('mobile')); ?>" placeholder="Enter mobile no" name="mobile">
                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3 mt-3">
                <label for="city" class="form-label">City:</label>
                <input type="text" class="form-control" id="city" placeholder="Enter city" value="<?php echo e(old('city')); ?>" name="city">
                <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address:</label>
                <textarea class="form-control" id="address" placeholder="Enter address" rows="5" name="address"><?php echo e(old('address')); ?></textarea>
                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
            </form>
<script>
    function check_number(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>

       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/admin/add_directory.blade.php ENDPATH**/ ?>