<?php $__env->startSection('title','Admin panel | Public Directory'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory By Status / Public</h5></div>
       <div class="card-body">
        <table class="table table-bordered">
            <thead class="table-primary">
            <tr>
                <th>S.No</th>
                <th>Full name</th>
                <th>profession</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Address</th>
                <th>Created at</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $directories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$directory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index+=1); ?></td>
                <td><?php echo e($directory->full_name); ?></td>
                <td><?php echo e($directory->profession); ?></td>
                <td><?php echo e($directory->email); ?></td>
                <td><?php echo e($directory->mobile); ?></td>
                <td><?php echo e($directory->city); ?></td>
                <td><?php echo e($directory->address); ?></td>
                <td><?php echo e($directory->created_at); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($directories)==0): ?>
            <tr>
                <td colspan="9">No records found</td>
            </tr>
            <?php endif; ?>
            </tbody>
        </table>
       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/admin/public_directory.blade.php ENDPATH**/ ?>