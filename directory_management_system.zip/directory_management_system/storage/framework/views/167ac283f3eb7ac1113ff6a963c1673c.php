<?php $__env->startSection('title','Admin panel | Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.admin_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Dashboard</h5></div>
       <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <center>
                            <h3>Total Directory <br> <?php echo e($total_directory); ?></h3>
                        </center>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <center>
                            <h3>Public Directory <br> <?php echo e($public_directory); ?></h3>
                        </center>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card  bg-primary text-white">
                    <div class="card-body">
                        <center>
                            <h3>Private Directory <br> <?php echo e($private_directory); ?></h3>
                        </center>
                    </div>
                </div>
            </div>
        </div>
       </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>