<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.js')); ?>"></script>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>


    <?php if(session('message')): ?>
<script>
    alert("<?php echo e(session('message')); ?>");
</script>
<?php endif; ?>
</body>
</html>
<?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/layouts/master.blade.php ENDPATH**/ ?>