<?php $__env->startSection('title','Directory Management System - Home page'); ?>
<?php $__env->startSection('content'); ?>
<div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 my-5 offset-md-4">
                <div class="card">
                    <div class="card-header"><h4 class="text-center">Admin Login</h4></div>
                    <div class="card-body">
                        <form action="<?php echo e(route('main.verify_login')); ?>" method="post" autocomplete="off">
                            <?php echo csrf_field(); ?>
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="text" class="form-control" id="email" value="<?php echo e(old('email')); ?>" placeholder="Enter email" name="email">
                            <span class="text-danger">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($errors->first('email')); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" value="<?php echo e(old('password')); ?>" name="password">
                            <span class="text-danger">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($errors->first('password')); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                        </form>

                        <div class="my-2 text-center">
                            <a href="<?php echo e(route('main.home')); ?>" class="">Back to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("body").addClass('bg-primary');
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ganesh\pros\directory_management_system\resources\views/login.blade.php ENDPATH**/ ?>