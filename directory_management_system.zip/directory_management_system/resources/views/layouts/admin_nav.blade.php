<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Admin Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="{{ route('admin.dashboard') }}">Dashboard</a>
        </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Directory</a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="{{ route('admin.add_directory') }}">Add</a></li>
            <li><a class="dropdown-item" href="{{ route('admin.manage_directory') }}">Manage</a></li>
        </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{ route('admin.directory.search') }}">Search Directory</a>
        </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Directory by status</a>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="{{ route('admin.public.directory') }}">Public</a></li>
            <li><a class="dropdown-item" href="{{ route('admin.private.directory') }}">Private</a></li>
        </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{ route('admin.logout') }}">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
