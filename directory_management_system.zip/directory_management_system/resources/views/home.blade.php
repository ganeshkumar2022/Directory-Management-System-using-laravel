@extends('layouts.master')
@section('title','Directory Management System | Home page')
@section('content')
@include('layouts.main_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Home / Search Directory</h5></div>
       <div class="card-body">
        <form method="get" action="{{ route('main.home') }}" autocomplete="off">
            <div class="input-group">
              <input type="text" class="form-control" name="search" value="{{ $val }}" placeholder="Enter Full name / Profession / Email / Mobile / City / Address">
              <button class="btn btn-success" type="submit">Go</button>
            </div>
            @error('search')
            <span class="text-danger">{{ $errors->first('search') }}</span>
            @enderror
        </form>

        <div class="my-2">
            <div class="row">
                @foreach ($data as $row)
                <div class="col-md-4">
                    <div class="card my-1">
                        <div class="card-body">
                            Full Name : {{ $row->full_name }} <br>
                            Profession : {{ $row->profession }} <br>
                            Email : {{ $row->email }} <br>
                            Mobile : {{ $row->mobile }} <br>
                            City : {{ $row->city }} <br>
                            Address : {{ $row->address }} <br>

                        </div>
                    </div>
                </div>
                @endforeach
                @if (count($data)==0 && @$_REQUEST['search']!="")
                  <center>No Directories found</center>
                @endif
            </div>
        </div>
       </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("body").css({"background-image":"url('assets/images/bg.jpg')","background-repeat":"no-repeat","background-size":"100% 100%","background-attachment":"fixed"});
    });
</script>
@endsection
