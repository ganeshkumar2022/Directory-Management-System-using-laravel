@extends('layouts.master')
@section('title','Directory Management System - Home page')
@section('content')
<div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4 my-5 offset-md-4">
                <div class="card">
                    <div class="card-header"><h4 class="text-center">Admin Login</h4></div>
                    <div class="card-body">
                        <form action="{{ route('main.verify_login') }}" method="post" autocomplete="off">
                            @csrf
                        <div class="mb-3 mt-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="text" class="form-control" id="email" value="{{ old('email') }}" placeholder="Enter email" name="email">
                            <span class="text-danger">
                                @error('email')
                                {{ $errors->first('email') }}
                                @enderror
                            </span>
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" value="{{ old('password') }}" name="password">
                            <span class="text-danger">
                                @error('password')
                                {{ $errors->first('password') }}
                                @enderror
                            </span>
                        </div>
                        <button type="submit" class="btn btn-primary">Login</button>
                        </form>

                        <div class="my-2 text-center">
                            <a href="{{ route('main.home') }}" class="">Back to Home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("body").addClass('bg-primary');
    });
</script>
@endsection

