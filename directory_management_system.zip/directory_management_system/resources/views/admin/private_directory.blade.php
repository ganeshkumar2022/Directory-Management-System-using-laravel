@extends('layouts.master')
@section('title','Admin panel | Private Directory')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory By Status / Private</h5></div>
       <div class="card-body">
        <table class="table table-bordered">
            <thead class="table-primary">
            <tr>
                <th>S.No</th>
                <th>Full name</th>
                <th>profession</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Address</th>
                <th>Created at</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($directories as $index=>$directory)
            <tr>
                <td>{{ $index+=1 }}</td>
                <td>{{ $directory->full_name }}</td>
                <td>{{ $directory->profession }}</td>
                <td>{{ $directory->email }}</td>
                <td>{{ $directory->mobile }}</td>
                <td>{{ $directory->city }}</td>
                <td>{{ $directory->address }}</td>
                <td>{{ $directory->created_at }}</td>
            </tr>
            @endforeach

            @if (count($directories)==0)
            <tr>
                <td colspan="9">No records found</td>
            </tr>
            @endif
            </tbody>
        </table>
       </div>
    </div>
</div>
@endsection
