@extends('layouts.master')
@section('title','Admin panel | Add Directory')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory / Add</h5></div>
       <div class="card-body">

            <form action="{{ route('admin.store_add_directory') }}" method="post" autocomplete="off">
            @csrf
            <div class="mb-3 mt-3">
                <label for="full_name" class="form-label">Full name:</label>
                <input type="text" class="form-control" id="full_name" value="{{ old('full_name') }}" placeholder="Enter full name" name="full_name">
                @error('full_name')
                <span class="text-danger">{{ $errors->first('full_name') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="profession" class="form-label">Profession:</label>
                <input type="text" class="form-control" id="profession" value="{{ old('profession') }}" placeholder="Enter profession" name="profession">
                @error('profession')
                <span class="text-danger">{{ $errors->first('profession') }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="email" class="form-label">Email address:</label>
                <input type="text" class="form-control" id="email" value="{{ old('email') }}" placeholder="Enter email" name="email">
                @error('email')
                <span class="text-danger">{{ $errors->first('email') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="mobile" class="form-label">Mobile no:</label>
                <input type="text" class="form-control" id="mobile" onkeypress="return check_number(event)" maxlength="10" value="{{ old('mobile') }}" placeholder="Enter mobile no" name="mobile">
                @error('mobile')
                <span class="text-danger">{{ $errors->first('mobile') }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="city" class="form-label">City:</label>
                <input type="text" class="form-control" id="city" placeholder="Enter city" value="{{ old('city') }}" name="city">
                @error('city')
                <span class="text-danger">{{ $errors->first('city') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address:</label>
                <textarea class="form-control" id="address" placeholder="Enter address" rows="5" name="address">{{ old('address') }}</textarea>
                @error('address')
                <span class="text-danger">{{ $errors->first('address') }}</span>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Add</button>
            </form>
<script>
    function check_number(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>

       </div>
    </div>
</div>
@endsection
