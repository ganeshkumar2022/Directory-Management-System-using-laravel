@extends('layouts.master')
@section('title','Admin panel | Dashboard')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Search Directory</h5></div>
       <div class="card-body">
        <form method="get" action="{{ route('admin.directory.search') }}" autocomplete="off">
            <div class="input-group">
              <input type="text" class="form-control" name="search" value="{{ $val }}" placeholder="Search">
              <button class="btn btn-success" type="submit">Go</button>
            </div>
            @error('search')
            <span class="text-danger">{{ $errors->first('search') }}</span>
            @enderror
        </form>

        <div class="my-2">
            <div class="row">
                @foreach ($data as $row)
                <div class="col-md-4">
                    <div class="card my-1">
                        <div class="card-body">
                            Full Name : {{ $row->full_name }} <br>
                            Profession : {{ $row->profession }} <br>
                            Email : {{ $row->email }} <br>
                            Mobile : {{ $row->mobile }} <br>
                            City : {{ $row->city }} <br>
                            Address : {{ $row->address }} <br>
                            Status : <span class="badge {{ $row->status=='public' ? 'bg-success' : 'bg-danger' }} rounded-pill">
                            {{ $row->status }}
                    </span>
                        </div>
                    </div>
                </div>
                @endforeach
                @if (count($data)==0 && @$_REQUEST['search']!="")
                  <center>No Directories found</center>
                @endif
            </div>
        </div>
       </div>
    </div>
</div>
@endsection
