@extends('layouts.master')
@section('title','Admin panel | Edit Directory')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory / Edit</h5></div>
       <div class="card-body">

            <form action="{{ route('admin.update_directory',$directory->id) }}" method="post" autocomplete="off">
            @csrf
            @method('PUT')
            <div class="mb-3 mt-3">
                <label for="full_name" class="form-label">Full name:</label>
                <input type="text" class="form-control" id="full_name" value="{{ $directory->full_name }}" placeholder="Enter full name" name="full_name">
                @error('full_name')
                <span class="text-danger">{{ $errors->first('full_name') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="profession" class="form-label">Profession:</label>
                <input type="text" class="form-control" id="profession" value="{{ $directory->profession }}" placeholder="Enter profession" name="profession">
                @error('profession')
                <span class="text-danger">{{ $errors->first('profession') }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="email" class="form-label">Email address:</label>
                <input type="text" class="form-control" id="email" value="{{ $directory->email }}" placeholder="Enter email" name="email">
                @error('email')
                <span class="text-danger">{{ $errors->first('email') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="mobile" class="form-label">Mobile no:</label>
                <input type="text" class="form-control" id="mobile" onkeypress="return check_number(event)" maxlength="10" value="{{ $directory->mobile }}" placeholder="Enter mobile no" name="mobile">
                @error('mobile')
                <span class="text-danger">{{ $errors->first('mobile') }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="city" class="form-label">City:</label>
                <input type="text" class="form-control" id="city" placeholder="Enter city" value="{{ $directory->city }}" name="city">
                @error('city')
                <span class="text-danger">{{ $errors->first('city') }}</span>
                @enderror
            </div>
            <div class="mb-3">
                <label for="address" class="form-label">Address:</label>
                <textarea class="form-control" id="address" placeholder="Enter address" rows="5" name="address">{{ $directory->address }}</textarea>
                @error('address')
                <span class="text-danger">{{ $errors->first('address') }}</span>
                @enderror
            </div>
            <div class="mb-3 mt-3">
                <label for="status" class="form-label">Status:</label>
                <select name="status" class="form-select">
                   <option value="">Select status</option>
                   <option value="public" {{ $directory->status=="public" ? 'selected' : '' }}>public</option>
                   <option value="private" {{ $directory->status=="private" ? 'selected' : '' }}>private</option>
                </select>
                @error('status')
                <span class="text-danger">{{ $errors->first('status') }}</span>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            </form>
<script>
    function check_number(e)
    {
        if(e.keyCode>=48 && e.keyCode<=57)
        {
            return true;
        }
        return false;
    }
</script>

       </div>
    </div>
</div>
@endsection
