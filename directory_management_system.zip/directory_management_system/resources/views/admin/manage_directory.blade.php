@extends('layouts.master')
@section('title','Admin panel | Manage Directory')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Directory / Manage</h5></div>
       <div class="card-body">
        <table class="table table-bordered">
            <thead class="table-primary">
            <tr>
                <th>S.No</th>
                <th>Full name</th>
                <th>profession</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>City</th>
                <th>Address</th>
                <th>Status</th>
                <th>Created at</th>
                <th>Manage</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($directories as $index=>$directory)
            <tr>
                <td>{{ $index+=1 }}</td>
                <td>{{ $directory->full_name }}</td>
                <td>{{ $directory->profession }}</td>
                <td>{{ $directory->email }}</td>
                <td>{{ $directory->mobile }}</td>
                <td>{{ $directory->city }}</td>
                <td>{{ $directory->address }}</td>
                <td>
                    <span class="badge {{ $directory->status=='public' ? 'bg-success' : 'bg-danger' }} rounded-pill">
                    {{ $directory->status }}
                    </span>
                </td>
                <td>{{ $directory->created_at }}</td>
                <td>
                    <a href="{{ route('admin.edit_directory',$directory->id) }}" class="btn btn-success">Edit</a>
                    <button onclick="delete_record({{ $directory->id }})" type="button" class="btn btn-danger">Delete</button>
                </td>
            </tr>
            @endforeach
            @if (count($directories)==0)
            <tr>
                <td colspan="10">No records found</td>
            </tr>
            @endif
            </tbody>
        </table>
       </div>
    </div>
</div>

<script>
    function delete_record(id)
    {
        var r=confirm("Are you sure you want to Delete");
        if(r)
        {
            var xhttp=new XMLHttpRequest();
            xhttp.onload=function(){
                alert(this.responseText);
                console.log(this.responseText);
                window.location.replace(window.location.href);
            }
            var text="{{ route('admin.delete_directory',':id') }}";
            txt=text.replace(':id',id);
            xhttp.open("DELETE",txt,true);
            xhttp.setRequestHeader("X-CSRF-TOKEN","{{ csrf_token() }}");
            xhttp.send();

        }
        else
        {
            alert('cancelled successfully');
        }
    }
</script>
@endsection
