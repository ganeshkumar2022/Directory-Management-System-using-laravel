@extends('layouts.master')
@section('title','Admin panel | Dashboard')
@section('content')
@include('layouts.admin_nav')
<div class="container">
    <div class="card my-2">
       <div class="card-header"><h5>Admin panel / Dashboard</h5></div>
       <div class="card-body">
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <center>
                            <h3>Total Directory <br> {{ $total_directory }}</h3>
                        </center>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <center>
                            <h3>Public Directory <br> {{ $public_directory }}</h3>
                        </center>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card  bg-primary text-white">
                    <div class="card-body">
                        <center>
                            <h3>Private Directory <br> {{ $private_directory }}</h3>
                        </center>
                    </div>
                </div>
            </div>
        </div>
       </div>
    </div>
</div>
@endsection
